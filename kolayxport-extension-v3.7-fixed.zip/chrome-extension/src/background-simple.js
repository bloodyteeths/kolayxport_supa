/**
 * Kolayxport Etsy Order Sync - Simple Background Service Worker
 * Simplified version to avoid service worker registration issues
 */

// Configuration
const KOLAYXPORT_DOMAIN = 'kolayxport.com';
const BADGE_COLORS = {
  success: '#4CAF50',
  error: '#F44336',
  warning: '#FF9800',
  default: '#2196F3'
};

// State management
let authToken = null;
let syncStats = {
  totalSynced: 0,
  lastSyncTime: null,
  errors: 0
};

// Initialize extension
chrome.runtime.onInstalled.addListener(async (details) => {
  // Initialize badge
  chrome.action.setBadgeBackgroundColor({ color: BADGE_COLORS.default });
  chrome.action.setBadgeText({ text: '' });
  
  // Check authentication
  await checkAuthentication();
  
  // Create context menus
  chrome.contextMenus.create({
    id: 'syncNow',
    title: 'Sync Etsy Orders Now',
    contexts: ['action']
  });
});

// Message handling
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  handleMessage(request, sender, sendResponse);
  return true; // Keep channel open for async response
});

async function handleMessage(request, sender, sendResponse) {
  switch (request.action) {
    case 'getCookies':
      const cookies = await getCookies(request.domain);
      sendResponse(cookies);
      break;
      
    case 'syncComplete':
      handleSyncComplete(request);
      sendResponse({ success: true });
      break;
      
    case 'getAuthStatus':
      await checkAuthentication(); // Refresh auth status
      sendResponse({ 
        authenticated: !!authToken,
        token: authToken 
      });
      break;
      
    default:
      sendResponse({ error: 'Unknown action' });
  }
}

// Simplified authentication check
async function checkAuthentication() {
  try {
    console.log('Checking authentication...');
    
    // Try to get cookies first
    const cookies = await chrome.cookies.getAll({ domain: 'kolayxport.com' });
    console.log('Found cookies:', cookies.map(c => c.name));
    
    // Look for auth cookies
    const authCookie = cookies.find(cookie => 
      cookie.name.includes('sb-') ||
      cookie.name.includes('auth') ||
      cookie.name.includes('session')
    );
    
    if (authCookie) {
      console.log(`Found auth cookie: ${authCookie.name}`);
      authToken = authCookie.value;
      updateBadge('authenticated');
      return;
    }
    
    // Try simple localStorage check
    try {
      const tabs = await chrome.tabs.query({
        url: [`https://${KOLAYXPORT_DOMAIN}/*`]
      });
      
      if (tabs.length > 0) {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            // Simple localStorage check
            const keys = Object.keys(localStorage);
            console.log('Checking localStorage keys:', keys);
            
            for (const key of keys) {
              if (key.includes('sb-') && key.includes('auth')) {
                const value = localStorage.getItem(key);
                console.log(`Found potential auth key: ${key}`);
                
                try {
                  const parsed = JSON.parse(value);
                  if (parsed.access_token) {
                    console.log('Found access token!');
                    return parsed.access_token;
                  }
                } catch (e) {
                  // Not JSON, might be direct token
                  if (value && value.length > 20) {
                    return value;
                  }
                }
              }
            }
            
            return null;
          }
        });
        
        const token = results[0]?.result;
        if (token) {
          console.log('Found token from localStorage');
          authToken = token;
          updateBadge('authenticated');
          return;
        }
      }
    } catch (tabError) {
      console.warn('Tab injection failed:', tabError);
    }
    
    // If we get here, no authentication was found
    console.log('No authentication found');
    authToken = null;
    updateBadge('unauthenticated');
    
  } catch (error) {
    console.error('Auth check failed:', error);
    authToken = null;
    updateBadge('error');
  }
}

async function getCookies(domain) {
  try {
    const cookies = await chrome.cookies.getAll({ domain });
    const cookieObj = {};
    
    cookies.forEach(cookie => {
      cookieObj[cookie.name] = cookie.value;
    });
    
    if (authToken) {
      cookieObj.kxAuthToken = authToken;
    }
    
    return cookieObj;
  } catch (error) {
    console.error('Failed to get cookies:', error);
    return {};
  }
}

// Sync handling
function handleSyncComplete(data) {
  syncStats.totalSynced += data.count;
  syncStats.lastSyncTime = new Date();
  syncStats.errors = 0;
  
  updateBadge('success', syncStats.totalSynced.toString());
  chrome.storage.local.set({ syncStats });
}

// Badge management
function updateBadge(status, text = '') {
  let color = BADGE_COLORS.default;
  let badgeText = text;
  
  switch (status) {
    case 'authenticated':
      color = BADGE_COLORS.success;
      badgeText = badgeText || '';
      break;
    case 'unauthenticated':
      color = BADGE_COLORS.warning;
      badgeText = badgeText || '?';
      break;
    case 'success':
      color = BADGE_COLORS.success;
      break;
    case 'error':
      color = BADGE_COLORS.error;
      break;
  }
  
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text: badgeText });
}

// Context menu handling
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'syncNow') {
    const tabs = await chrome.tabs.query({
      url: [
        'https://www.etsy.com/your/orders/*',
        'https://www.etsy.com/your/shops/*/orders*'
      ]
    });
    
    if (tabs.length > 0) {
      try {
        await chrome.tabs.sendMessage(tabs[0].id, { action: 'scrapeNow' });
      } catch (error) {
        console.error('Failed to send sync message:', error);
      }
    }
  }
});

// Global error handling
self.addEventListener('error', (event) => {
  console.error('Service worker error:', event.error);
});