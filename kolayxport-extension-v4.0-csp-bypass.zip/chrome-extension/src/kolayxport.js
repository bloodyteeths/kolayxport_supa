/**
 * Content script for Kolayxport pages to help with authentication
 */

console.log('Kolayxport content script loaded on:', window.location.href);

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Kolayxport content script received message:', request);
  
  if (request.action === 'getAuthToken') {
    try {
      console.log('=== KOLAYXPORT AUTH TOKEN SEARCH ===');
      console.log('Current URL:', window.location.href);
      console.log('Path:', window.location.pathname);
      
      // Check localStorage
      const keys = Object.keys(localStorage);
      console.log('LocalStorage keys:', keys);
      
      // Check sessionStorage  
      const sessionKeys = Object.keys(sessionStorage);
      console.log('SessionStorage keys:', sessionKeys);
      
      // Look for Supabase auth tokens
      for (const key of keys) {
        if (key.startsWith('sb-') && key.includes('auth-token')) {
          const value = localStorage.getItem(key);
          console.log(`Found Supabase key: ${key}`);
          
          try {
            const parsed = JSON.parse(value);
            console.log('Token structure:', Object.keys(parsed));
            if (parsed.access_token) {
              console.log('SUCCESS: Found access_token in localStorage!');
              sendResponse({
                success: true,
                token: parsed.access_token,
                source: 'localStorage',
                key: key
              });
              return;
            }
          } catch (e) {
            console.log('Parse failed for key:', key, e);
          }
        }
      }
      
      // Try sessionStorage too
      for (const key of sessionKeys) {
        if (key.includes('sb-') || key.includes('supabase')) {
          const value = sessionStorage.getItem(key);
          console.log(`Found session key: ${key}`);
          
          try {
            const parsed = JSON.parse(value);
            if (parsed.access_token) {
              console.log('SUCCESS: Found access_token in sessionStorage!');
              sendResponse({
                success: true,
                token: parsed.access_token,
                source: 'sessionStorage',
                key: key
              });
              return;
            }
          } catch (e) {
            console.log('Session parse failed for key:', key, e);
          }
        }
      }
      
      // Check for window.supabase
      if (window.supabase) {
        console.log('Window.supabase exists, trying to get session...');
        // We can't use await in this context, but we can try other approaches
      }
      
      console.log('No auth token found');
      sendResponse({ success: false, error: 'No auth token found' });
      
    } catch (error) {
      console.error('Error getting auth token:', error);
      sendResponse({ success: false, error: error.message });
    }
  }
  
  return true; // Keep message channel open
});

// Also try to automatically detect and store auth info
function detectAuthInfo() {
  const keys = Object.keys(localStorage);
  const authKeys = keys.filter(key => 
    key.includes('sb-') || 
    key.includes('supabase') || 
    key.includes('auth')
  );
  
  if (authKeys.length > 0) {
    console.log('Kolayxport auth keys detected:', authKeys);
    // Store a flag that auth is available
    chrome.storage.local.set({ 'kolayxport_auth_available': true });
  }
}

// Run detection on load
detectAuthInfo();

// Run detection when storage changes
window.addEventListener('storage', detectAuthInfo);